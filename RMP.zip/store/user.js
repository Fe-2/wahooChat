export const state = () => ({
  userInfo: {},
});

export const mutations = {
  USER_INFO_SET(states, payload) {
    states.userInfo = payload;
  },
};

export const actions = {
  SET_USER_INFO({ commit }, payload) {
    commit('USER_INFO_SET', payload);
  },
};
