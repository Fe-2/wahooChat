<template>
  <div class="ff-header">
    <div class="header-title">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{path: '/'}">
          产品管理
        </el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="user-info">
      <el-dropdown trigger="click">
        <span class="username">
          {{ $store.state.user.userInfo.name || '未登录' }}
          <i class="el-icon-arrow-down el-cicon--right" />
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            退出登录
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Header',
};
</script>

<style lang="scss" scoped>
.ff-header{
  height: 48px;
  .header-title{
    float: left;
    .el-breadcrumb{
      line-height: 48px;
      height: 48px;
      .el-breadcrumb__item{
        /deep/.el-breadcrumb__inner{
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
        }
      }
    }
  }
  .user-info{
    float: right;
    .el-dropdown{
      line-height: 48px;
      height: 48px;
      .username{
        line-height: 48px;
        height: 48px;
        cursor: pointer;
      }
    }
  }
}
</style>
