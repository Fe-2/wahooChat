<template>
  <div class="firefinch-rmp">
    <el-container>
      <el-aside v-if="isLogin" width="176px">
        <Nav />
      </el-aside>
      <el-container>
        <el-header v-if="isLogin" height="48px">
          <Header />
        </el-header>
        <el-main>
          <div class="ff-main">
            <Nuxt />
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import { http } from '~/plugins/http/http';
import Nav from './nav';
import Header from './header';

export default {
  components: {
    Nav: Nav,
    Header: Header,
  },
  fetchOnServer: true,
  async fetch() {
    const { store, $axios } = this.$nuxt.context;
    const { data } = await $axios.post('/API/Auth/GetUserInfo');
    store.dispatch('user/SET_USER_INFO', data.data);
  },
  data() {
    return {
      isLogin: true,
    };
  },
  watch: {
    $route() {
      const vm = this;
      if (vm.$route.fullPath === '/login') {
        vm.isLogin = false;
      }
    },
  },
  created() {
  },
  mounted() {
    const vm = this;
    vm.$nextTick(() => {
      vm.$nuxt.$loading.start();
      setTimeout(() => vm.$nuxt.$loading.finish(), 500);
    });
    // 请求code状态码处理提示
    http.setErrorHandler((dataPacket) => {
      const errorCode = dataPacket.code.toString();
      const code = errorCode.charAt(0);
      switch (code) {
        case '1': // 消息
          vm.$message({
            duration: 500000,
            dangerouslyUseHTMLString: true,
            message: dataPacket.msg,
          });
          break;
        case '2': // 警告
          vm.$message({
            duration: 500000,
            dangerouslyUseHTMLString: true,
            message: dataPacket.msg,
            type: 'warning',
          });
          break;
        case '3': // 错误
          vm.$message({
            duration: 500000,
            dangerouslyUseHTMLString: true,
            message: dataPacket.msg,
            type: 'error',
          });
          break;
        default:
          // 默认code为0请求成功，数据无异常状态
          // 这里只处理HTTP状态码为200时的请求，其它状态码都会提示请求错误
          break;
      }
    });
  },
};
</script>

<style lang="scss">
@import "assets/scss/FUI";
#__nuxt{
  width: 100%;
  height: 100%;
  #__layout{
    width: 100%;
    height: 100%;
    .firefinch-rmp{
      width: 100%;
      height: 100%;
      position: relative;
      .ff-main{
        height: 100%;
        width: 100%;
        background: #fff;
        border-radius: 2px;
        padding: 15px;
      }
    }
  }
}
.el-header{
  background-color: #fff;
  padding: 0 15px;
  border-bottom: 1px solid #e9e9e9;
}
.el-main{
  padding: 15px;
  background: #f7f7f7;
}
</style>
