<template>
  <div class="error-container">
    <div class="text">
      <p v-if="error.statusCode === 404">
        404 NOT FOUND
      </p>
      <p v-else>
        应用发生错误异常
      </p>
      <nuxt-link to="/">
        <el-button type="primary" class="not-found-button">
          首 页
        </el-button>
      </nuxt-link>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    error: {
      type: Object,
      default() {
        return {
          statusCode: 404,
        };
      },
    },
  },
  layout: 'blog', // 你可以为错误页面指定自定义的布局
};
</script>
<style lang="scss" scoped>
.error-container{
  background-color: #0b2850;
  // background: url('../assets/img/login/LoginBj.png') no-repeat center;
  background-size: cover;
  height: 100%;
  width: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: 0 auto;
  z-index: 1;
  .text{
    margin-top: 15%;
    text-align: center;
    p{
      font-size: 46px;
      color: #F88311;
      line-height: 1.5;
      text-align: center;
    }
    .not-found-button{
      margin-top: 30px;
    }
  }
}
</style>
