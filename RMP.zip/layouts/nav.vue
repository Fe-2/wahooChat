<template>
  <div class="ff-nav">
    <div class="logo">
      <img src="~/assets/img/login/Firefinch_logo2.png" alt="">
    </div>
    <ul class="nav-list">
      <nuxt-link v-for="item in navList" :key="item.path" :to="item.path">
        <li class="item">
          <i class="el-icon-s-grid" /> {{ item.title }}
        </li>
      </nuxt-link>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Nav',
  data() {
    return {
      navList: [{
        title: '产品管理',
        path: '/product',
      }],
    };
  },
};
</script>

<style lang="scss" scoped>
.ff-nav{
  width: 176px;
  height: 100%;
  min-height: 100vh;
  background: #20202c;
  color:#fff;
  font-size: 14px;
  float: left;
  .logo{
    height: 48px;
    line-height: 48px;
    text-align: center;
    position: relative;
    &:after{
      content: '';
      display: block;
      width: 100%;
      height: 1px;
      background: #fff;
      position: absolute;
      left: 0;
      bottom: 0;
      transform: scaleY(0.5);
    }
    img{
      display: block;
      height: 60%;
      margin: 0 auto;
      transform: translateY(8px);
    }
  }
  .nav-list{
    height: 48px;
    line-height: 48px;
    text-align: center;
    a{
      color: #fff;
      i{
        font-size: 16px;
        transform: translateY(1.4px);
      }
    }
  }
}
</style>
