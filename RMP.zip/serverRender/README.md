# Render
### nuxt项目启动渲染Vue模板，与API模块分离，此处加载渲染Vue模板
