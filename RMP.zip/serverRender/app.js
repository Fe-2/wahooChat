/*
* Vue模板渲染
* */
const { Nuxt, Builder } = require('nuxt');
const express = require('express');
const mongodb = require('mongodb').MongoClient;
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({})); // 解析post数据的req.body数据
app.use(cookieParser()); // 解析读写cookie
const isProd = (process.env.NODE_ENV === 'production');
const port = process.env.PORT || 8080;

mongodb.connect('mongodb://127.0.0.1:27017', { useNewUrlParser: true }, (err, db) => {
  if (err) {
    console.log('失败');
  } else {
    console.log('成功');
    db.db('RMP').collection('User').find({}).toArray((eer, dbs) => {
      console.log(dbs);
    });
  }
});
// 用指定的配置对象实例化 Nuxt.js
const config = require('../nuxt.config.js');

config.dev = !isProd;
const nuxt = new Nuxt(config);
// 设置允许跨域
app.all('*', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With');
  res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS');
  res.header('X-Powered-By', 'FIREFINCH');
  res.header('Content-Type', 'application/json;charset=utf-8');
  next();
});
// 用 Nuxt.js 渲染每个路由（前端界面在此处渲染）
app.use(nuxt.render);

// 在开发模式下启用编译构建和热加载
const listen = () => {
// 服务端监听
  app.listen(port, '0.0.0.0');
  console.log(`Server listening on \`localhost:${port}\`.`);
};
if (config.dev) {
  new Builder(nuxt).build()
    .then(listen).catch((error) => {
    // 处理 getJSON 和 前一个回调函数运行时发生的错误
      console.log('发生错误！', error);
    });
} else {
  listen();
}
