export { default as FfPageTable } from '../..\\components\\FFPageTable.vue'
export { default as Logo } from '../..\\components\\Logo.vue'

export const LazyFfPageTable = import('../..\\components\\FFPageTable.vue' /* webpackChunkName: "components_FFPageTable'}" */).then(c => c.default || c)
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components_Logo'}" */).then(c => c.default || c)
