<template>
  <img src="../assets/img/login/Firefinch_logo2.png" alt="">
</template>

<style>
.NuxtLogo {
  animation: 1s appear;
  margin: auto;
}

@keyframes appear {
  0% {
    opacity: 0;
  }
}
</style>
