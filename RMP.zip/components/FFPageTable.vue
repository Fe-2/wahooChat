<template>
  <div class="ff-page-table">
    <el-table
      ref="ff-table"
      class="ff-table"
      :data="tableData"
      border
      :lazy="true"
      :row-style="{height: '40px'}"
      :cell-style="{padding:'5px 0'}"
      :height="tableHeight"
    >
      <slot />
    </el-table>
    <div class="page">
      <el-pagination
        background
        class="ff-page"
        :page-sizes="[20, 30, 40, 50, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handlePageChange"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'FFPageTable',
  props: {
    tableData: {
      type: Array,
      default() {
        return [];
      },
    },
    total: {
      type: Number,
      default() {
        return 0;
      },
    },
  },
  data() {
    return {
      tableHeight: 0,
      pageIndex: 1,
      pageSize: 20,
    };
  },
  mounted() {
    const vm = this;
    vm.$nextTick(() => {
      vm.tableHeight = document.querySelector('.ff-page-table').offsetHeight - 45;
    });
  },
  methods: {
    handleSizeChange(val) {
      this.$emit('size-change', val);
    },
    handlePageChange(val) {
      this.$emit('current-change', val);
    },
  },
};
</script>

<style lang="scss" scoped>
.ff-page-table{
  width:100%;
  height: 100%;
  /deep/.ff-table{
    height: calc(100% - 45px);
    .el-table__header{
      tr,th{
        background: #f3f3f3;
      }
    }
  }
  .page{
    height: 30px;
    margin-top:15px;
    overflow: hidden;
    .el-pagination{
      float: right;
    }
    /deep/.ff-page{
      .el-pagination__sizes, .el-pagination__jump{
        line-height: 20px!important;
      }
    }
  }
  /deep/.handle-row{
    .handle-btn{
      float: left;
      padding: 0 7px;
      color: rgb(16, 142, 233);
      cursor: pointer;
      position: relative;
      &:after{
        content: '';
        display: block;
        width: 1px;
        height: 14px;
        background: rgb(16, 142, 233);
        position: absolute;
        right: 0;
        top: 5px;
        z-index: 1;
      }
      &:last-child{
        &:after{
          display: none;
        }
      }
    }
  }
}
</style>
