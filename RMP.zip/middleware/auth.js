const Cookie = require('js-cookie');
const { aesDecrypt } = require('../serverAPI/util/AES');

export default function ({
  route, req, redirect,
}) {
  const isClient = process.client;
  const isServer = process.server; // 此处需要判断代码执行环境，否则浏览器后退页面操作时会报错；
  let token = '';
  let url = '';
  if (isServer) {
    token = req.cookies.token;
    url = req.url;
  } else if (isClient) {
    token = Cookie.get('token');
    url = route.path;
  }
  if (url !== '/login' && !aesDecrypt(token)) {
    redirect('/login');
  }
}
