module.exports = {
  root: true,
  env: {
    browser: true,
    node: true,
  },
  parserOptions: {
    parser: 'babel-eslint',
  },
  extends: [
    '@nuxtjs',
    'plugin:nuxt/recommended',
    'airbnb',
  ],
  plugins: [
  ],
  // add your custom rules here
  rules: {
    'linebreak-style': 'off',
    'no-console': 'off',
    'max-len': 'off',
    'no-multiple-empty-lines': 'off',
    'object-shorthand': 'off',
    'unicorn/prefer-includes': 'off',
    'unicorn/no-array-instanceof': 0,
    'no-else-return': 0,
    'import/no-unresolved': 'off',
    'import/extensions': 'off',
    'guard-for-in': 0,
    'no-restricted-syntax': 0,
    'no-param-reassign': 0,
  },
};
