<template>
  <div class="ff-login">
    <div class="form-warp" @keyup.enter="onSubmit('ruleForm')">
      <p class="title">
        <img class="angular" src="~/assets/img/login/Firefinch_logo2.png" alt=""> 资源库
      </p>
      <!--      <img src="../../assets/img/login/Firefinch_logo2.png" alt="">-->
      <el-form ref="ruleForm" :model="form" status-icon :rules="rules" label-width="0">
        <img class="angular" src="~/assets/img/login/LeftUp.png" alt="">
        <img class="angular" src="~/assets/img/login/LeftDown.png" alt="">
        <img class="angular" src="~/assets/img/login/RightUp.png" alt="">
        <img class="angular" src="~/assets/img/login/RightDown.png" alt="">
        <!--        <img class="form-logo" src="../../assets/img/login/LoginLogo2.png" alt="">-->
        <el-form-item label="" prop="username">
          <el-input ref="username" v-model="form.username" prefix-icon="el-icon-user" autocomplete="off" />
        </el-form-item>
        <el-form-item label="" prop="password">
          <el-input v-model="form.password" prefix-icon="el-icon-lock" type="password" autocomplete="off" />
        </el-form-item>
        <el-form-item>
          <el-button class="sub" type="primary" :loading="loading" @click="onSubmit('ruleForm')">
            登&nbsp;&nbsp;录
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="footer">
      Copyright&nbsp;©&nbsp;<span class="time">2010-Present</span>&nbsp;Shenzhen&nbsp;Cybertron&nbsp;Technology&nbsp;Co.,Ltd&nbsp;  深圳市思博创科技有限公司&nbsp;版权所有
    </div>
  </div>
</template>
<script>
import { httpList, http } from '~/plugins/http/http';
// import { mapActions } from 'Vuex';

export default {
  name: 'Login',
  async asyncData({ $axios }) {
    let data = {};
    await $axios.post('/API/Auth/Login', { test: '123123' }).then((datas) => {
      data = datas.data;
    }).catch((error) => {
      console.log(error.config);
    });
    return { testData: data };
  },
  data() {
    return {
      loading: false,
      rules: {
        username: [
          { required: true, message: '请输用户名', trigger: 'blur' },
          {
            min: 3, max: 12, message: '请输入3到12位数的账号', trigger: 'blur',
          },
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          {
            min: 5, message: '请输入不少于5位数的密码', trigger: 'blur',
          },
        ],
      },
      form: {
        username: '',
        password: '',
      },
      testData: {},
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.$refs.username.focus();
    });
  },
  created() {
    // console.log('Loginmounted', this.testData);
  },
  methods: {
    onSubmit(formName) {
      const vm = this;
      vm.$refs[formName].validate((valid) => {
        if (valid) {
          http.api[httpList.Login]({
            method: 'post',
            params: vm.form,
            success() {
              vm.$router.push('/product');
              vm.$store.dispatch('user/SET_USER_INFO', {
                user: 'test',
              });
            },
          });
        }
      });
    },
    // ...mapActions({
    //   setUserInfo: 'user/SET_USER_INFO',
    // }),
  },
};
</script>

<style lang="scss" scoped>
.ff-login{
  background-color: #0b2850;
  background: url('../assets/img/login/LoginBj.png') no-repeat center;
  background-size: cover;
  height: 100%;
  width: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: 0 auto;
  z-index: 1;
  >.form-warp{
    width: 420px;
    padding: 0 20px;
    position: absolute;
    top: 45%;
    left: 66%;
    transform: translate(-50%,-50%);
    user-select:none;
    .title{
      height: 60px;
      text-align: center;
      font-size: 32px;
      line-height: 60px;
      color: #fff;
      margin-bottom: 20px;
      img{
        width: 160px;
        display: inline-block;
        transform: translateY(-3px);
        margin-right: 5px;
      }
    }
    >.el-form{
      background-color: rgba(7,23,59,.8);
      border: 2px solid #406086;
      padding: 56px 34px 56px 34px;
      position: relative;
      .form-logo{
        max-width: 100%;
        margin: 30px auto;
        display: block;
      }
      .angular{
        display: block;
        position: absolute;
        z-index: 1;
        &:nth-child(1){
          right: -1px;
          top: -1px;
        }
        &:nth-child(2){
          right: -1px;
          bottom: -1px;
        }
        &:nth-child(3){
          left: -1px;
          top: -1px;
        }
        &:nth-child(4){
          left: -1px;
          bottom: -1px;
        }
      }
      .el-form-item{
        &:last-child{
          margin-bottom: 0;
        }
        /deep/.el-form-item__content{
          .el-input{
            .el-input__inner{
              background-color: #0b2850;
              border-radius: 3px;
              border: 1px solid #406086;
              color: #fff;
              padding-left: 34px;
              &:focus{
                box-shadow: #406086 0 0 16px;
              }
            }
            .el-input__prefix{
              color: #4da7f5;
              i{
                font-size: 18px;
                margin-top: 3px\0;
              }
            }
            .el-input__suffix{
              .el-input__icon{
                color: #4da7f5;
              }
              .el-icon-circle-close{
                display: none;
              }
            }
          }
          .el-form-item__error{
            color: #4da7f5;
          }
          .sub{
            width: 100%;
            background: #4da7f5;
            border: 0;
            //font-size: 18px;
            span{
              font-size: 18px;
            }
          }
        }
      }
    }
  }
  .footer{
    position: absolute;
    left: 0;
    bottom: 0;
    background: rgba(11,40,80,.6);
    width: 100%;
    height: 60px;
    line-height: 60px;
    font-size: 12px;
    color: #4da7f5;
    text-align: center;
    .time{
      font-size: 12px;
      // font-weight: 600;
    }
  }
}
</style>
