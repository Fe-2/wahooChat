<template>
  <div class="container">
    <div>
      <Logo />
    </div>
  </div>
</template>

<script>
// import { httpList, http } from '~/plugins/http/http';

export default {
  mounted() {
    this.$nextTick(() => {
      this.$nuxt.$loading.start();
      setTimeout(() => this.$nuxt.$loading.finish(), 500);
    });
  },
};
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  background: #f1f1f1;
}
</style>
