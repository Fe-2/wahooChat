<template>
  <div class="product">
    <div class="top-tool">
      <el-button size="mini" type="primary" @click="addPro">
        添加产品
      </el-button>
    </div>
    <div class="count">
      <i class="el-icon-warning" />共 <span class="blue">0</span> 条数据
    </div>
    <div class="table">
      <FFPageTable
        :table-data="tableData"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handlePageChange"
      >
        <el-table-column
          label="名称"
          prop="product_name"
          min-width="20%"
        />
        <el-table-column
          prop="model"
          label="型号"
          min-width="20%"
        />
        <el-table-column
          prop="explain"
          min-width="30%"
          label="说明"
        />
        <el-table-column
          prop="created_date"
          min-width="20%"
          label="创建日期"
        />
        <el-table-column
          min-width="20%"
          prop="author"
          label="创建人"
        />
        <el-table-column
          width="200"
          label="操作"
        >
          <template slot-scope="scope">
            <div class="handle-row">
              <span class="handle-btn">编辑</span>
              <el-popover
                :key="scope.row.id"
                v-model="scope.row.tableDeleVis"
                class="handle-btn"
                placement="top"
                width="120"
                trigger="manual"
              >
                <p>确定删除吗？</p>
                <div style="text-align: right; margin: 0">
                  <el-button size="mini" type="text" @click="scope.row.tableDeleVis = false">
                    取消
                  </el-button>
                  <el-button type="primary" size="mini" @click.stop="scope.row.tableDeleVis = false">
                    确定
                  </el-button>
                </div>
                <span slot="reference" @click.stop="scope.row.tableDeleVis = true">删除</span>
              </el-popover>
              <el-dropdown class="handle-btn" trigger="click">
                <span>
                  更多操作
                  <i class="el-icon-arrow-down el-cicon--right" />
                </span>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    出厂设置
                  </el-dropdown-item>
                  <el-dropdown-item>
                    说明书
                  </el-dropdown-item>
                  <el-dropdown-item>
                    测试用例
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
          </template>
        </el-table-column>
      </FFPageTable>
    </div>
  </div>
</template>

<script>
import FFPageTable from '~/components/FFPageTable';
import { httpList, http } from '~/plugins/http/http';
import baseUtil from '~/util/baseUtil';

export default {
  name: 'Index',
  components: {
    FFPageTable: FFPageTable,
  },
  data() {
    return {
      total: 0,
      tableData: [{
        product_name: '',
        model: '',
        author: '',
        created_date: '',
        explain: '',
      }],
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    handleSizeChange(val) {
      const vm = this;
      vm.pageSize = val;
    },
    handlePageChange(val) {
      const vm = this;
      vm.pageIndex = val - 1;
    },
    getList() {
      const vm = this;
      http.api[httpList.GetProductList]({
        method: 'post',
        success(data) {
          console.log(data);
          baseUtil.each(data, (el) => {
            el.tableDeleVis = false;
          });
          vm.tableData = data;
        },
      });
    },
    addPro() {
      http.api[httpList.AddProduct]({
        method: 'post',
        params: {
          product_name: '16712637628',
          author: '      ',
        },
        success(data) {
          console.log(data);
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.product{
  width: 100%;
  height: 100%;
  .count{
    height: 30px;
    line-height: 28px;
    text-indent: 5px;
    background: #e6f3fc;
    border: 1px solid #d4f0fc;
    border-radius: 4px;
    margin: 10px 0;
    font-size: 12px;
    .el-icon-warning{
      color: #108ee9;
      font-size: 16px;
      margin-right: 5px;
      position: relative;
      top: 1px;
    }
    .blue{
      color: #108ee9;
      font-size: 12px;
    }
  }
  .table{
    height: calc(100% - 80px);
  }
}
</style>
