import { http } from './http';

const $_FFHttp = {};

$_FFHttp.install = function install(vue) {
  vue.prototype.$_FFHttp = http;
};

export default $_FFHttp;
