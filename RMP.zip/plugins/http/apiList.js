/**
 * FireFinch RMP接口列表
 */
const List = {
  /**
   * 登录
   */
  Login: '/Auth/Login',
  /*
  * 产品管理
  * */
  GetProductList: '/Product/GetProductList',
  AddProduct: '/Product/AddProduct',
};
for (const listKey in List) {
  List[listKey] = `/API${List[listKey]}`;
}
export default List;
