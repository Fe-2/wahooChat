import axios from 'axios';
import baseUtil from '../../util/baseUtil';
import logger from '../../util/logger';
import apiList from './apiList';
import loopRequest from './loopRequest';
// import specialHandler from './specialHandler';

const commonParam = {};
let errorHandler = () => {};

const http = {
  api: {},
};

const env = process.env.NODE_ENV;
const axiosConfig = {
  method: 'get',
  baseURL: env === 'production' ? '' : '',
  timeout: 120000,
  // headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, // 默认json格式传参，此处可改为formData格式
};

const ajaxMethod = ['get', 'post'];

/**
 * @param {object} response
 * @param {object} response.type - 消息类型 err-错误，nor-正常，war-警告
 * @param {object} response.data - 数据包
 * @param {string} response.code - 消息编码
 * @param {function} responseHandler
 * @return {object}
 */
const ResponseHandler = (response, responseHandler) => {
  if (response && 'data' in response && typeof responseHandler === 'function') { // respond 处理层
    responseHandler(response);
    return response.data;
  }
  logger.error('接口返回非标准格式');
  return response;
};
const DataPacketHandler = (dataPacket, dataPacketHandler) => { // code 处理层
  const { data, code } = dataPacket;
  if (typeof dataPacketHandler === 'function' && 'data' in dataPacket) {
    dataPacketHandler(dataPacket);
  }
  if (typeof errorHandler === 'function') {
    errorHandler(dataPacket);
  }
  if (code === '0' && 'data' in dataPacket) { // 修复 complete bug
    return data;
  }
  return 'AxiosOtherCode';
};
const DataHandler = (data, dataHandler) => { // 数据处理层
  if (data !== 'AxiosOtherCode' && typeof dataHandler === 'function') {
    dataHandler(data);
  }
};
const CatchHandler = (error, catchHandler) => {
  // const VueInit = Vue.prototype;
  // const { response } = error;
  // logger.error(error.response);
  // console.log(error.request);
  if (typeof catchHandler === 'function') {
    catchHandler(error);
  }
  // console.log(response);
  // VueInit.$notify.error({
  //   title: response.statusText,
  //   dangerouslyUseHTMLString: true,
  //   message: `<p style="width:250px;display:inline-block;color: #C20000;font-size: 14px;word-wrap:break-word;">${response.config.url}</p><br><p>接口请求失败，请联系管理员</p>`,
  //   duration: 0,
  // });
};

const axiosInstance = axios.create(axiosConfig);

http.axios = axiosInstance;

baseUtil.each(ajaxMethod, (method) => {
  /**
   * @param {string} url api地址 -
   * @param {object} [options] 配置参数
   * @param {object} options.param
   * @param {function} options.responseHandler
   * @param {function} options.dataPacketHandler
   * @param {function} options.dataHandler
   */
  http[method] = (url, options) => {
    const {
      params, responseHandler, dataPacketHandler, dataHandler, catchHandler,
    } = options;
    return axiosInstance[method](url, params) // 返回axios内的Promise对象
      .then((response) => ResponseHandler(response, responseHandler))
      .then((dataPacket) => DataPacketHandler(dataPacket, dataPacketHandler))
      .then((data) => DataHandler(data, dataHandler))
      .catch((errorObj) => CatchHandler(errorObj, catchHandler));
  };
});

baseUtil.each(apiList, (url) => {
  http.api[url] = (options) => {
    const method = options.method || 'get';
    const respond = options.respond || function respond() {};
    const success = options.success || function success() {};
    const fail = options.fail || function fail() {};
    const complete = options.complete || function complete() {};
    const error = options.error || function error() {};

    const responseHandler = (response) => respond(response); // 数据格式验证，验证接口返回数据是否包含 code，data,msg字段
    const dataPacketHandler = (dataPacket) => { // 请求完成&请求失败（code不为“0”）的处理
      complete(dataPacket);
      if (dataPacket.code !== '0') {
        fail(dataPacket);
      }
    };
    const dataHandler = (data) => { // 请求成功且code为“0”时的处理
      /*
      // 需要对数据进行特殊处理的接口，会经过这一层
        if (specialHandler[url]) {
          specialHandler[url](data);
      }
      */
      success(data);
    };
    const catchHandler = (errorObj) => { // 网络请求失败的处理
      error(errorObj);
    };
    const params = baseUtil.copy(commonParam);
    baseUtil.merge(params, options.params, true);
    const postOptions = {
      params,
      responseHandler,
      dataPacketHandler,
      dataHandler,
      catchHandler,
    };
    // console.log(Vue.prototype);
    let init;
    if (method === 'post') {
      init = http.post(url, postOptions);
    } else if (method === 'get') {
      postOptions.params = { params: params };
      init = http.get(url, postOptions);
    }
    return init; // 返回axios内的Promise对象
  };
});

http.all = (requests, callback) => {
  if (!baseUtil.isObject(requests) || !baseUtil.isArray(requests)) {
    return;
  }
  axios.all(requests)
    .then(axios.spread((acc, pres) => {
      callback(acc, pres);
    }));
};
http.loop = (api, opts, channel = loopRequest.channel.HALF_MINUTE) => {
  const loop = loopRequest.add(() => {
    http.api[api](opts);
  }, channel);
  return [loop, channel];// 此处返回值用于remove对应的循环请求
  /*
  * 示例：
  // 发起循环请求
  httpLoop = http.loop(httpList.TEST, {
        method: 'get',
        params: {
          ip: '63.223.108.42',
        },
        success(response) {
          console.log(response);
          vm.ip = response;
        },
      }, http.loop.channel.ONE_MINUTE);
      //remove 操作（停止循环请求）
      http.loop.remove(...httpLoop);
  * */
};
http.loop.channel = loopRequest.channel;
http.loop.remove = (item, channel) => {
  loopRequest.remove(item, channel);
};


http.apiList = apiList;
http.setCommonParam = (param) => {
  baseUtil.merge(commonParam, param, true);
};
http.setErrorHandler = (eh) => {
  errorHandler = eh;
};
const httpList = apiList;

export {
  http,
  httpList,
};
