import FormatSend from '../util/formatSend';

const express = require('express');
const InitUserDao = require('../models/DAO/userDAO'); // 数据库操作模块（只操作User表）
const { aesEncrypt, aesDecrypt } = require('../util/AES'); // 对称加密模块

module.exports = () => {
  const router = express.Router();
  const userDao = new InitUserDao();
  const formatSend = new FormatSend();
  router.post('/GetUserInfo', (req, res) => {
    const token = aesDecrypt(req.cookies.token).toString();
    if (token) {
      userDao.findOne({ _id: token }).then((data) => {
        formatSend.succ(res, data);
      });
    } else {
      formatSend.succ(res, {});
    }
  });
  router.post('/Login', (req, res) => {
    const name = req.body.username;
    const pwd = req.body.password;
    userDao.findOne({ account: name, pwd: pwd }).then((data) => {
      if (data) {
        res.cookie('token', aesEncrypt(data.id.toString()), { maxAge: 1000 * 60 * 60 * 24 * 30 });
        formatSend.succ(res, data);
      } else {
        formatSend.error(res, '用户名或密码错误!');
      }
    });
  });
  router.post('/Logout', (req, res) => {
    res.cookie('token', '', { maxAge: 0 });
    formatSend.succ(res);
  });
  return router;
};

