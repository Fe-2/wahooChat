/*
* 后端接口服务
* */
import FormatSend from '../util/formatSend';

const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const app = express();
const formatSend = new FormatSend();

app.use(bodyParser.json()); // 解析 application/json
app.use(bodyParser.urlencoded({ extended: true })); // 解析 application/x-www-form-urlencoded
app.use(cookieParser()); // 解析读写 cookie
// 设置允许跨域,根据需要修改跨域权限
app.all('*', (req, res, next) => {
  res.header('Access-Control-Allow-Credentials', '*');
  res.header('Access-Control-Expose-Headers', '*');
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With,Content-Type');
  res.header('Access-Control-Allow-Methods', 'POST'); // PUT,POST,GET,DELETE,OPTIONS
  res.header('X-Powered-By', 'FIRE-FINCH-RMP');
  res.header('Content-Type', 'application/json;charset=utf-8');
  const reg = new RegExp('/Auth', 'ig');
  if (!req.cookies.token && !reg.test(req.url)) {
    formatSend.send(res, '未登录,请先登录！', [], '401');
  } else {
    next(); // 如果需要继续匹配路由必须执行next();
  }
});
// 鉴权
app.use('/Auth', require('./auth.js')());
// 产品管理
app.use('/Product', require('./product.js')());

app.all('*', (req, res) => {
  formatSend.send(res, '当前接口未定义', [], '3', 404);
});
process.env.hotUpdate = '1'; // 切换热更新
export default app;
