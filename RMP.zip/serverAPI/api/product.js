import FormatSend from '../util/formatSend';

const { body } = require('express-validator');
const express = require('express');
const InitProductDao = require('../models/DAO/productDAO'); // 数据库操作模块（只操作Products表）
// const { aesEncrypt } = require('../util/AES'); // 对称加密模块
module.exports = () => {
  const router = express.Router();
  const productDao = new InitProductDao();
  const formatSend = new FormatSend();
  router.post('/GetProductList', (req, res) => {
    productDao.findAll().then((data) => {
      if (data) {
        formatSend.succ(res, data);
      }
    });
  });
  router.post('/AddProduct', [
    body('product_name').isString().isEmpty(),
    body('model').isString().isEmpty(),
    body('author').isEmpty().isString(),
  ], (req, res) => {
    if (formatSend.verify(req, res)) {
      productDao.save(req.body).then((data) => {
        if (data) {
          formatSend.succ();
        }
      });
    }
  });
  return router;
};

