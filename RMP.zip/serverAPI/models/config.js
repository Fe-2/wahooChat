module.exports = {
  user: 'firefinch',
  pwd: 'root2020',
  host: '192.168.200.5', // process.env.baseIP,
  port: '27017',
  db: 'RMP',
};
