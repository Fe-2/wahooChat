const mongoose = require('mongoose');
const config = require('./config');

mongoose.Promise = global.Promise;
const mongoUrl = `mongodb://${config.host}:${config.port}/${config.db}`;
const connectionMongo = () => {
  mongoose.connect(mongoUrl, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    poolSize: 66,
    keepAlive: true,
  }).then(() => {
    console.log(`Mongoose连接至：${mongoUrl}`);
  }).catch(() => {
    console.log('Mongoose连接失败，5S后重连！');
    setTimeout(() => {
      connectionMongo();
    }, 5000);
  });
};
if (process.env.hotUpdate === '0') { // 此判断为了避免开发模式下热更新导致mongoose重复初始化报错，如果更改此处代码需要重新启动项目方可执行
  connectionMongo();
}

module.exports = mongoose;

