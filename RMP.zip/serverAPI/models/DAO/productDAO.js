const BaseDao = require('./baseDAO');
const Product = require('../model/product');

class ProductDao extends BaseDao {
  constructor() {
    super(Product);
  }
}
module.exports = ProductDao;
