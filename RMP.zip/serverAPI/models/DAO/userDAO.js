const BaseDao = require('./baseDAO');
const User = require('../model/user');

class UserDao extends BaseDao {
  constructor() {
    super(User);
  }
}
module.exports = UserDao;
