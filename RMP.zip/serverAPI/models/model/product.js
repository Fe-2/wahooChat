const { Schema } = require('mongoose');
const mongoose = require('../mongoose');

const productSchema = new Schema({
  _id: String,
  product_name: String,
  model: String,
  explain: String,
  created_date: String,
  author: String,
}, {
  runSettersOnQuery: true,
});
/**
 * 参数一要求与 Model 名称一致
 * 参数二为 Schema
 * 参数三为映射到 MongoDB 的 Collection 名
 */
if (process.env.hotUpdate === '0') { // 此判断为了避免开发模式下热更新导致mongoose重复初始化报错，如果更改此处代码需要重新启动项目方可执行
  global.mongooseProduct = mongoose.model('product', productSchema, 'Products');
}
module.exports = global.mongooseProduct;
