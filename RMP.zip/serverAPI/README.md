# MIDDLEWARE
### nuxt接口中间件，与渲染Vue模块分离，此处加载自定义的后端接口功能，在nuxt.config.js中有相应配置项
