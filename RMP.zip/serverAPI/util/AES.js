const crypto = require('crypto');

const KEY = '^.Fi@+re$F@)(inch-R*M/P2020@#%!*'; // 密钥(‘aes-256’模式下密码长度为32位) 256/8 =32  128/8 = 16
const IV = Buffer.alloc(16, 0); // 初始化向量(长度要求为128bit或16字节长度的字符串)
const aesEncrypt = (data) => {
  const cipher = crypto.createCipheriv('aes-256-cbc', KEY, IV);
  let str = '';
  try {
    str = cipher.update(data, 'utf8', 'hex') + cipher.final('hex');
  } catch (e) {
    // console.log('非RMP平台标准加密字符串，无法加密');
  }
  return str;
};

const aesDecrypt = (data) => {
  const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
  let str = '';
  try {
    str = decipher.update(data, 'hex', 'utf8') + decipher.final('utf8');
  } catch (e) {
    // console.log('非RMP平台标准加密字符串，无法解密');
  }
  return str;
};

module.exports = {
  aesEncrypt,
  aesDecrypt,
};
