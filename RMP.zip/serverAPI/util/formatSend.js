const { validationResult } = require('express-validator');

class FormatSend {
  constructor() {
    return this;
  }

  send(res, msg = '', data = {}, code = '0', status = 200) {
    res.status(status).json({
      code: code,
      data: data,
      msg: msg,
    });
    return this;
  }

  verify(req, res) {
    const self = this;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorsList = errors.array();
      const msgList = {};
      let msg = '';
      errorsList.forEach((el) => {
        msgList[el.param] = el.msg;
      });
      for (const m in msgList) {
        msg += `${m}: ${msgList[m]}<br/>`;
      }
      self.error(res, msg);
      return false;
    } else {
      return true;
    }
  }

  succ(res, data) {
    const self = this;
    self.send(res, 'succ', data);
  }

  info(res, msg, data) {
    const self = this;
    self.send(res, msg, data, '1');
  }

  warn(res, msg, data) {
    const self = this;
    self.send(res, msg, data, '2');
  }

  error(res, msg, data) {
    const self = this;
    self.send(res, msg, data, '3');
  }
}

module.exports = FormatSend;
