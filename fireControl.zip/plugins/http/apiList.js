const apiList = {
  Login: '/oauth/wechatAppletLogin', // 登录
};
module.exports = apiList;